//
//  ViewController.swift
//  Database Test
//
//  Created by Gagandeep Nagpal on 13/01/17.
//  Copyright © 2017 Gagandeep Nagpal. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var ref: FIRDatabaseReference!
        var refHandle:FIRDatabaseHandle
        
        ref = FIRDatabase.database().reference()
        
        ref.child("Text/nagpal/gagan").setValue("helloworld")
       
        
        refHandle = ref.child("Text/nagpal").observe(FIRDataEventType.value, with: { (snapshot) in
            let postDict = snapshot.value as? NSDictionary
            
            
            print(postDict?["gagan"] ?? "none")
          
        })
        
        
        
        
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

